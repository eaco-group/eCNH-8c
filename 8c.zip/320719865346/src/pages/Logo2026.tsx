import { useState } from "react";
import { motion } from "framer-motion";
import { Palette, Maximize2, X, ChevronLeft, ChevronRight, Moon, Sun, Download } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";

// 语言定义
const languages = {
  zh: {
    title: "eCNH LOGO 2026 设计展示",
    subtitle: "未来金融的视觉标识",
    description: "探索eCNH的多元化设计语言，从传统到未来的融合表达",
    categories: "分类浏览",
    all: "全部",
    roundBadges: "圆形徽章",
    flameBadges: "火焰徽章",
    shieldBadges: "盾牌徽章",
    globalSeries: "全球系列",
    premiumCollection: "高级收藏",
    viewLarge: "查看大图",
    close: "关闭",
    prev: "上一个",
    next: "下一个",
    download: "下载图片",
    backToHome: "返回首页"
  },
  en: {
    title: "eCNH LOGO 2026 Design Showcase",
    subtitle: "Visual Identity of Future Finance",
    description: "Explore eCNH's diverse design language, from traditional to futuristic expressions",
    categories: "Browse Categories",
    all: "All",
    roundBadges: "Round Badges",
    flameBadges: "Flame Badges",
    shieldBadges: "Shield Badges",
    globalSeries: "Global Series",
    premiumCollection: "Premium Collection",
    viewLarge: "View Large",
    close: "Close",
    prev: "Previous",
    next: "Next",
    download: "Download Image",
    backToHome: "Back to Home"
  }
};

// Logo数据
const logoData = [
  // 圆形徽章系列
  {
    id: 1,
    name: "eCNH Classic Gold",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20gold%20badge%20design%2C%20circular%20shape%2C%20red%20background%2C%20glowing%20effect&sign=81d62207257540ee3b194f0a640a49d5",
    description: "经典金色圆形徽章，红色渐变背景，带有优雅的金色边框"
  },
  {
    id: 2,
    name: "eCNH Deluxe Circle",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20deluxe%20gold%20badge%2C%20circular%20shape%2C%20red%20gradient%2C%20elegant%20design&sign=55824fa0550afaed7fa8e70e899603dd",
    description: "豪华版圆形徽章，精致的金色文字和边框设计"
  },
  {
    id: 3,
    name: "eCNH Regal Seal",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20regal%20seal%2C%20circular%20badge%2C%20red%20background%2C%20gold%20text%2C%20royal%20design&sign=90b8b42c3c186c7b3ab5564c19862f6c",
    description: "皇家风格印章设计，红色背景搭配金色文字"
  },
  {
    id: 4,
    name: "eCNH Yuan Symbol",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20with%20yuan%20symbol%2C%20circular%20badge%2C%20gold%20and%20red%20colors%2C%20chinese%20currency%20design&sign=d1108ef6f53798f2f6065e3f4e3753ba",
    description: "融合人民币符号的设计，彰显东方金融特色"
  },
  {
    id: 5,
    name: "eCNH Modern Glow",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20modern%20glow%2C%20circular%20badge%2C%20golden%20glow%2C%20red%20gradient%2C%20shiny%20effect&sign=8c66e545e15d0921729e1e06f7559619",
    description: "现代发光效果设计，红色渐变配合金色光芒"
  },
  {
    id: 6,
    name: "eCNH Elegant Brown",
    category: "roundBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20elegant%20brown%2C%20circular%20badge%2C%20brown%20gradient%2C%20gold%20text%2C%20sophisticated%20design&sign=20d8d8a8b820286dd1d47c516408b4bf",
    description: "优雅棕色系列，展现高端金融产品的稳重感"
  },
  
  // 火焰徽章系列
  {
    id: 7,
    name: "eCNH Flame Square",
    category: "flameBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20with%20flames%2C%20square%20badge%2C%20red%20background%2C%20gold%20text%2C%20fiery%20effect&sign=6093623fa25d8be9572ab82c33a79b24",
    description: "方形火焰徽章，象征金融的活力与热情"
  },
  {
    id: 8,
    name: "eCNH Shield Flame",
    category: "flameBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20shield%20with%20flames%2C%20gold%20text%2C%20red%20background%2C%20protective%20design&sign=49c22fa5da0d7fb50b974465d79a005c",
    description: "盾牌形状火焰徽章，象征安全与保障"
  },
  {
    id: 9,
    name: "eCNH Enchanted Flame",
    category: "flameBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20with%20magic%20flames%2C%20shield%20shape%2C%20gold%20text%2C%20mystical%20design&sign=37fe39492dfff0be30a2ae933c37a9ef",
    description: "魔法火焰设计，赋予品牌神秘而强大的视觉印象"
  },
  
  // 盾牌徽章系列
  {
    id: 10,
    name: "eCNH Security Shield",
    category: "shieldBadges",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20security%20shield%2C%20gold%20text%2C%20red%20background%2C%20protection%20symbol&sign=c9e3cba3242d9f7c846daf066a930234",
    description: "安全盾牌设计，强调金融产品的可靠性"
  },
  
  // 全球系列
  {
    id: 11,
    name: "eCNH Global Green",
    category: "globalSeries",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20global%20green%20background%2C%20currency%20symbols%20around%2C%20cathedral%20architecture%2C%20interconnected%20network&sign=f02d42c901df964fbac86a6bfdd83126",
    description: "绿色全球系列，背景融合世界知名建筑和货币符号"
  },
  {
    id: 12,
    name: "eCNH Global Blue",
    category: "globalSeries",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20global%20blue%20background%2C%20brandenburg%20gate%2C%20currency%20symbols%20network%2C%20international%20finance&sign=712616e6650d56c4b6f7a10521ecaa2f",
    description: "蓝色全球系列，以德国勃兰登堡门为背景，象征欧洲金融中心"
  },
  
  // 高级收藏系列
  {
    id: 13,
    name: "eCNH Luxury Red",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20luxury%20red%20background%2C%20gold%20text%2C%20currency%20symbols%20particles%2C%20high-end%20design&sign=c9aefc59302feaa6349bacdfdcd41c1e",
    description: "奢华红色系列，金色粒子环绕，彰显高端金融产品定位"
  },
  {
    id: 14,
    name: "eCNH Gold Classic",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20gold%20classic%2C%20currency%20symbols%20background%2C%20sophisticated%20design%2C%20financial%20theme&sign=e984919ebd45839b2cb2561be9acb8f7",
    description: "金色经典系列，融合多种世界货币符号，体现国际化特征"
  },
  {
    id: 15,
    name: "eCNH Amber Glow",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20amber%20glow%2C%20golden%20particles%2C%20currency%20symbols%2C%20warm%20light%20effect&sign=8f583858c159a8043669b9294c47762f",
    description: "琥珀光芒系列，温暖的金色光芒营造高端金融氛围"
  },
  {
    id: 16,
    name: "eCNH Copper Elegance",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20copper%20elegance%2C%20currency%20symbols%2C%20sophisticated%20design%2C%20warm%20tones&sign=d7cf9fa12f3027e10a7da14a694ad832",
    description: "铜色优雅系列，温暖色调展现金融产品的亲和力"
  },
  {
    id: 17,
    name: "eCNH Sunset Gold",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20sunset%20gold%2C%20golden%20gradient%2C%20currency%20symbols%2C%20warm%20sunset%20colors&sign=db1116e8473800f2c878b3791c13cc59",
    description: "日落金色系列，渐变色彩呈现如日落般的视觉享受"
  },
  {
    id: 18,
    name: "eCNH Financial Tech",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20financial%20tech%20theme%2C%20golden%20circles%2C%20trading%20chart%20background%2C%20modern%20design&sign=e0162d431d311ad3cbc63ad461d1f784",
    description: "金融科技系列，金色圆环与图表背景，展现科技金融融合"
  },
  {
    id: 19,
    name: "eCNH Dynamic Flame",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20dynamic%20flame%2C%20fiery%20background%2C%20gold%20text%2C%20energetic%20design&sign=0b1b6ef0d1f53257c16b834d4e075c54",
    description: "动感火焰系列，充满活力的设计语言表达金融创新"
  },
  {
    id: 20,
    name: "eCNH Growth Chart",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20growth%20chart%2C%20upward%20trend%2C%20gold%20text%2C%20financial%20success&sign=c3c417607c9fd6e2cd058644eeafbb63",
    description: "增长图表系列，向上趋势线象征金融增长与成功"
  },
  {
    id: 21,
    name: "eCNH Radiant Glow",
    category: "premiumCollection",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=eCNH%20logo%20radiant%20glow%2C%20golden%20particles%2C%20sunburst%20effect%2C%20luxurious%20design&sign=685432b45cf1a8547aa4c91e75545df2",
    description: "光芒四射系列，金色粒子与光芒效果，展现品牌的闪耀与活力"
  }
];

export default function Logo2026() {
  const [language, setLanguage] = useState<'zh' | 'en'>('zh');
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedLogo, setSelectedLogo] = useState<number | null>(null);
  const { theme, toggleTheme } = useTheme();
  const t = languages[language];

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'zh' ? 'en' : 'zh');
  };

  const filteredLogos = selectedCategory === "all" 
    ? logoData 
    : logoData.filter(logo => logo.category === selectedCategory);

  const handleLogoClick = (id: number) => {
    setSelectedLogo(id);
    document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
  };

  const handleCloseModal = () => {
    setSelectedLogo(null);
    document.body.style.overflow = 'auto'; // Re-enable scrolling
  };

  const handlePrevLogo = () => {
    if (!selectedLogo) return;
    
    const currentIndex = logoData.findIndex(logo => logo.id === selectedLogo);
    const prevIndex = (currentIndex - 1 + logoData.length) % logoData.length;
    setSelectedLogo(logoData[prevIndex].id);
  };

  const handleNextLogo = () => {
    if (!selectedLogo) return;
    
    const currentIndex = logoData.findIndex(logo => logo.id === selectedLogo);
    const nextIndex = (currentIndex + 1) % logoData.length;
    setSelectedLogo(logoData[nextIndex].id);
  };

  const handleDownloadImage = (imageUrl: string) => {
    // Create a temporary link element
    const link = document.createElement('a');
    link.href = imageUrl;
    
    // Extract filename from URL or use a default
    const filename = `eCNH_logo_${Date.now()}.png`;
    link.download = filename;
    
    // Append to document and trigger click
    document.body.appendChild(link);
    link.click();
    
    // Clean up
    document.body.removeChild(link);
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  const categories = [
    { id: "all", name: t.all },
    { id: "roundBadges", name: t.roundBadges },
    { id: "flameBadges", name: t.flameBadges },
    { id: "shieldBadges", name: t.shieldBadges },
    { id: "globalSeries", name: t.globalSeries },
    { id: "premiumCollection", name: t.premiumCollection }
  ];

  const currentLogo = selectedLogo ? logoData.find(logo => logo.id === selectedLogo) : null;

  return (
    <div className={`min-h-screen font-sans ${theme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}>
      {/* 导航栏 */}
      <nav className={`sticky top-0 z-50 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Palette className={`h-8 w-8 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
            <h1 className="text-xl font-bold">eCNH Logo 2026</h1>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href="/"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-900 text-white hover:bg-blue-800' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'} transition-colors`}
            >
              {t.backToHome}
            </a>
            <button
              onClick={toggleLanguage}
              className={`px-3 py-1 rounded-full ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors`}
            >
              {language === 'en' ? '中文' : 'English'}
            </button>
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-700'} transition-colors`}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-white'}`}>
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-3xl md:text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-amber-500 to-yellow-400">
              {t.title}
            </h1>
            <p className="text-xl md:text-2xl font-semibold mb-6 text-amber-500 dark:text-amber-400">
              {t.subtitle}
            </p>
            <p className={`text-lg md:text-xl max-w-3xl mx-auto ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.description}
            </p>
          </motion.div>
        </div>
      </section>

      {/* 分类筛选 */}
      <section className={`py-8 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-xl font-bold mb-4 text-center">{t.categories}</h2>
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map(category => (
              <motion.button
                key={category.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-5 py-2 rounded-full font-medium transition-all duration-300 ${
                  selectedCategory === category.id 
                    ? (theme === 'dark' 
                      ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white' 
                      : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-white') 
                    : (theme === 'dark' 
                      ? 'bg-gray-700 text-gray-200 hover:bg-gray-600' 
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200')
                }`}
              >
                {category.name}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Logo 网格展示 */}
      <section className={`py-12 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={containerVariants}
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6"
          >
            {filteredLogos.map(logo => (
              <motion.div
                key={logo.id}
                variants={itemVariants}
                whileHover={{ 
                  y: -10, 
                  boxShadow: theme === 'dark' 
                    ? '0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2)'
                    : '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
                }}
                className={`rounded-xl overflow-hidden shadow-lg cursor-pointer ${
                  theme === 'dark' ? 'bg-gray-800' : 'bg-white'
                } transition-all duration-300 flex flex-col`}
                onClick={() => handleLogoClick(logo.id)}
              >
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={logo.imageUrl} 
                    alt={logo.name} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    loading="lazy"
                  />
                </div>
                <div className="p-4 flex-grow flex flex-col">
                  <h3 className="font-bold mb-2 text-amber-500 dark:text-amber-400">{logo.name}</h3>
                  <p className={`text-sm flex-grow ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    {logo.description}
                  </p>
                  <div className="mt-4 flex justify-end">
                    <span className={`inline-flex items-center text-xs ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
                      {t.viewLarge}
                      <Maximize2 className="w-3 h-3 ml-1" />
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Logo 详情模态框 */}
      {selectedLogo && currentLogo && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          onClick={handleCloseModal}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative max-w-5xl w-full max-h-[90vh] overflow-hidden rounded-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className={`absolute top-0 left-0 right-0 z-10 p-4 flex justify-between items-center ${theme === 'dark' ? 'bg-gray-900/80' : 'bg-white/80'} backdrop-blur-md`}>
              <h3 className="text-xl font-bold text-amber-500">{currentLogo.name}</h3>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleDownloadImage(currentLogo.imageUrl)}
                  className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-800 text-gray-200 hover:bg-gray-700' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'} transition-colors`}
                  aria-label={t.download}
                >
                  <Download className="w-5 h-5" />
                </button>
                <button
                  onClick={handleCloseModal}
                  className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-800 text-gray-200 hover:bg-gray-700' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'} transition-colors`}
                  aria-label={t.close}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="relative h-full flex items-center justify-center bg-gray-950">
              <button 
                onClick={handlePrevLogo}
                className={`absolute left-2 p-2 rounded-full ${theme === 'dark' ? 'bg-black/50 text-white' : 'bg-white/50 text-black'} hover:opacity-100 transition-opacity`}
                aria-label={t.prev}
              >
                <ChevronLeft className="w-8 h-8" />
              </button>
              
              <img 
                src={currentLogo.imageUrl} 
                alt={currentLogo.name} 
                className="max-w-full max-h-[90vh] object-contain"
              />
              
              <button 
                onClick={handleNextLogo}
                className={`absolute right-2 p-2 rounded-full ${theme === 'dark' ? 'bg-black/50 text-white' : 'bg-white/50 text-black'} hover:opacity-100 transition-opacity`}
                aria-label={t.next}
              >
                <ChevronRight className="w-8 h-8" />
              </button>
            </div>
            
            <div className={`absolute bottom-0 left-0 right-0 p-4 ${theme === 'dark' ? 'bg-gray-900/80' : 'bg-white/80'} backdrop-blur-md`}>
              <p className={theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}>
                {currentLogo.description}
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* 页脚 */}
      <footer className={`py-12 ${theme === 'dark' ? 'bg-gray-900 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">eCNH：全球共享的分布式SOL链上结算工具，跨境记账单位，结算代币</p>
          <p className="mb-6">核心理念：earth & Global Humanity Builds and Shares eCNH Together</p>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            稳定币地址（CA）：7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5u
          </p>
          <div className="mt-8 flex justify-center space-x-6">
            <a href="https://x.com/earthCNH" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="https://t.me/eCNHusdc" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-telegram text-xl"></i>
            </a>
            <a href="https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fas fa-link text-xl"></i>
            </a>
          </div>
          <div className="mt-8">
            <a href="/" className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors`}>
              <i className="fas fa-arrow-left"></i>
              {t.backToHome}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}