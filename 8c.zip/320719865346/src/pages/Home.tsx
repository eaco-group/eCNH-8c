import { useState } from "react";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { ArrowRight, Globe, TrendingUp, Database, Users, Zap, DollarSign, BarChart2, Network, Shield, PieChart, Layers } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";

// 语言定义
const languages = {
  en: {
    hero: {
      title: "eCNH Global Strategy 2026-2030",
      subtitle: "From 36B to 3.6T CNH - 100x Growth",
      description: "Transforming eCNH from 'a stablecoin' to the global CNH settlement infrastructure,记账单位 for Chinese economic entities worldwide, cross-border payment tool with multi-country presence, mainstream stablecoin on Solana, and DAO governance asset."
    },
    phases: {
      title: "Four-Stage Growth Roadmap (2026-2030)",
      phase1: {
        title: "Infrastructure & Global Expansion (2026)",
        target: "36B - 300B CNH",
        actions: [
          "Global Expansion in 37 Countries",
          "Solana DeFi Deep Development",
          "Global Distribution Backend"
        ]
      },
      phase2: {
        title: "Global Chinese Economic Entity Accounting Unit (2027)",
        target: "30B - 100B CNH",
        actions: [
          "Chinese Business District Adoption of eCNH Pricing",
          "Cross-border Trade Settlement",
          "eCNH as 'Overseas RMB'"
        ]
      },
      phase3: {
        title: "Global Stablecoin Position (2028-2029)",
        target: "100B - 800B CNH",
        actions: [
          "eCNH as Mainstream Stablecoin on Solana",
          "Large-scale DeFi Lock-up",
          "National-level Nodes (Andromeda)"
        ]
      },
      phase4: {
        title: "Global CNH Settlement Network (2030)",
        target: "800B - 3.6T CNH",
        actions: [
          "eCNH as Global CNH On-chain Infrastructure",
          "Global Settlement Model"
        ]
      }
    },
    engines: {
      title: "Twelve Growth Engines (2026-2030)",
      engine1: "Global Chinese Economic Entity (Core)",
      engine2: "Cross-border Trade Settlement",
      engine3: "Global Distribution System",
      engine4: "Multi-country Localized Exchange Entrances",
      engine5: "Solana DeFi Depth",
      engine6: "Fixed Income Pool (4-8%)",
      engine7: "Resource DAOs (Minerals, Energy)",
      engine8: "Chinese Cross-border E-commerce",
      engine9: "International Students, Immigrants, Rent, Tuition",
      engine10: "Global Nodes (Andromeda)",
      engine11: "eCNH as CNH Pricing Unit",
      engine12: "Compliance + KYC + AML Module"
    },
    models: {
      title: "Three Mathematical Models",
      modelA: {
        title: "User Precipitation Model",
        formula: "Number of Users × Per Capita Holdings = Total Precipitation",
        example: "30 Million Users × 4000 eCNH = 1.2T CNH"
      },
      modelB: {
        title: "Settlement Precipitation Model",
        formula: "Monthly Settlement Volume × Precipitation Rate × 12",
        example: "10B × 0.25 × 12 = 30B CNH"
      },
      modelC: {
        title: "DeFi Lock-up Model",
        formula: "Lock-up Volume = LP + Lending + Fixed Income Pool",
        example: "20B + 30B + 20B = 70B CNH"
      }
    },
    conclusion: {
      title: "Conclusion: 36B → 36T CNH is Fully Achievable",
      description: "By advancing through the four stages, you can transform eCNH into: Global CNH on-chain settlement layer + Digital currency for Chinese economic entities + Mainstream stablecoin on Solana."
    },
    footer: {
      description: "eCNH: Global Shared Distributed SOL Chain Settlement Tool, Cross-border Accounting Unit, Settlement Token",
      coreValue: "earth & Global Humanity Builds and Shares eCNH Together",
      contractAddress: "Contract Address: 7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5u"
    }
  },
  zh: {
    hero: {
      title: "eCNH全球战略 2026-2030",
      subtitle: "从360亿到3.6万亿CNH - 100倍增长",
      description: "将eCNH从'一个稳定币'升级为全球华人经济体的CNH记账单位 + 跨境结算基础设施 + 多国落地的支付工具 + Solana上的主流稳定币 + DAO治理资产。"
    },
    phases: {
      title: "四阶段增长路线图（2026-2030）",
      phase1: {
        title: "基础设施与全球落地（2026）",
        target: "360亿 - 3000亿CNH",
        actions: [
          "全球37国落地",
          "Solana DeFi深度建设",
          "全球经销后台"
        ]
      },
      phase2: {
        title: "全球华人经济体记账单位（2027）",
        target: "300亿 - 1000亿CNH",
        actions: [
          "华人商圈全面采用eCNH计价",
          "跨境贸易结算",
          "eCNH成为'海外人民币'"
        ]
      },
      phase3: {
        title: "全球稳定币地位（2028-2029）",
        target: "1000亿 - 8000亿CNH",
        actions: [
          "eCNH成为Solana上的主流稳定币",
          "大规模DeFi锁仓",
          "国家级节点（Andromeda）"
        ]
      },
      phase4: {
        title: "全球CNH结算网络（2030）",
        target: "8000亿 - 36000亿CNH",
        actions: [
          "eCNH成为全球CNH的链上基础设施",
          "全球沉淀模型"
        ]
      }
    },
    engines: {
      title: "十二大增长引擎（2026-2030）",
      engine1: "全球华人经济体（核心）",
      engine2: "跨境贸易结算",
      engine3: "全球经销体系",
      engine4: "多国本地化兑换入口",
      engine5: "Solana DeFi深度",
      engine6: "固定收益池（4-8%）",
      engine7: "资源类DAO（矿产、能源）",
      engine8: "华人跨境电商",
      engine9: "留学生、移民、房租、学费",
      engine10: "全球节点（Andromeda）",
      engine11: "eCNH作为CNH计价单位",
      engine12: "合规 + KYC + AML模块"
    },
    models: {
      title: "三种数学模型",
      modelA: {
        title: "用户沉淀模型",
        formula: "用户数 × 人均持有量 = 总沉淀",
        example: "3000万用户 × 4000 eCNH = 12000亿CNH"
      },
      modelB: {
        title: "结算沉淀模型",
        formula: "月度结算量 × 沉淀率 × 12",
        example: "100亿 × 0.25 × 12 = 300亿CNH"
      },
      modelC: {
        title: "DeFi锁仓模型",
        formula: "锁仓量 = LP + 借贷 + 固定收益池",
        example: "200亿 + 300亿 + 200亿 = 700亿CNH"
      }
    },
    conclusion: {
      title: "最终结论：360亿 → 36万亿CNH是完全可实现的",
      description: "只要按四个阶段推进，您完全有能力把eCNH做成：全球CNH的链上结算层 + 华人经济体的数字货币 + Solana的主流稳定币。"
    },
    footer: {
      description: "eCNH：全球共享的分布式SOL链上结算工具，跨境记账单位，结算代币",
      coreValue: "核心理念：earth & Global Humanity Builds and Shares eCNH Together",
      contractAddress: "稳定币地址（CA）：7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5u"
    }
  }
};

// 模拟数据 - 市值增长预测
const marketCapData = [
  { year: 2026, low: 36, high: 300 },
  { year: 2027, low: 300, high: 1000 },
  { year: 2028, low: 1000, high: 4000 },
  { year: 2029, low: 4000, high: 8000 },
  { year: 2030, low: 8000, high: 36000 }
];

// 模拟数据 - 增长引擎分布
const engineDistributionData = [
  { name: "Global Chinese Economy", value: 25 },
  { name: "Cross-border Trade", value: 20 },
  { name: "DeFi Ecosystem", value: 15 },
  { name: "Global Distribution", value: 12 },
  { name: "Resource DAOs", value: 10 },
  { name: "Others", value: 18 }
];

export default function Home() {
  const [language, setLanguage] = useState<'en' | 'zh'>('zh');
  const { theme, toggleTheme } = useTheme();
  const t = languages[language];

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'zh' : 'en');
  };

  const engineIcons = [
    <Users className="w-8 h-8" />,
    <Globe className="w-8 h-8" />,
    <Network className="w-8 h-8" />,
    <Zap className="w-8 h-8" />,
    <TrendingUp className="w-8 h-8" />,
    <DollarSign className="w-8 h-8" />,
    <Database className="w-8 h-8" />,
    <BarChart2 className="w-8 h-8" />,
    <Globe className="w-8 h-8" />,
    <Network className="w-8 h-8" />,
    <PieChart className="w-8 h-8" />,
    <Shield className="w-8 h-8" />
  ];

  // 动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className={`min-h-screen font-sans ${theme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}>
      {/* 导航栏 */}
      <nav className={`sticky top-0 z-50 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Layers className={`h-8 w-8 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
            <h1 className="text-xl font-bold">eCNH Global Strategy</h1>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href="/"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-900 text-white hover:bg-blue-800' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'} transition-colors`}
            >
              {language === 'en' ? 'Home' : '首页'}
            </a>
            <a 
              href="/private-placement"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-700 text-white hover:bg-blue-600' : 'bg-blue-600 text-white hover:bg-blue-700'} transition-colors`}
            >
              {language === 'en' ? 'Private Placement' : '私募'}
            </a>
            <a 
              href="/eight-countries"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-purple-700 text-white hover:bg-purple-600' : 'bg-purple-600 text-white hover:bg-purple-700'} transition-colors`}
            >
              {language === 'en' ? '8-Country Center' : '海外8国'}
            </a>
            <button
              onClick={toggleLanguage}
              className={`px-3 py-1 rounded-full ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors`}
            >
              {language === 'en' ? '中文' : 'English'}
            </button>
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-700'} transition-colors`}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <i className="fas fa-sun"></i>
              ) : (
                <i className="fas fa-moon"></i>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className={`py-20 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-white'}`}>
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
              {t.hero.title}
            </h1>
            <p className="text-2xl md:text-3xl font-bold mb-6 text-blue-600 dark:text-blue-400">
              {t.hero.subtitle}
            </p>
            <p className={`text-lg md:text-xl max-w-3xl mx-auto mb-10 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.hero.description}
            </p>
            <div className="flex justify-center">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="relative group"
              >
                <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-blue-700' : 'bg-blue-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
                <a 
                  href="#phases" 
                  className="relative px-8 py-3 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 transition-all duration-300"
                >
                  {t.phases.title}
                  <ArrowRight className="w-5 h-5" />
                </a>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 市值增长图表 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className={`p-6 rounded-2xl shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">eCNH Market Cap Growth Forecast (2026-2030)</h2>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={marketCapData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorLow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorHigh" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#374151' : '#e5e7eb'} />
                  <XAxis 
                    dataKey="year" 
                    stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'}
                    tick={{ fill: theme === 'dark' ? '#9ca3af' : '#6b7280' }}
                  />
                  <YAxis 
                    stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'}
                    tick={{ fill: theme === 'dark' ? '#9ca3af' : '#6b7280' }}
                    tickFormatter={(value) => `${value}B`}
                  />
                  <Tooltip 
                    formatter={(value) => [`${value}B CNH`, 'Market Cap']}
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                      color: theme === 'dark' ? '#f3f4f6' : '#1f2937',
                      borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                      borderRadius: '0.5rem'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="low" 
                    stroke="#3b82f6" 
                    fillOpacity={1} 
                    fill="url(#colorLow)" 
                    name="Low Estimate"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="high" 
                    stroke="#8b5cf6" 
                    fillOpacity={1} 
                    fill="url(#colorHigh)" 
                    name="High Estimate"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center mt-6 space-x-6">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                <span className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>Low Estimate</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
                <span className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>High Estimate</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 四阶段增长路线图 */}
      <section id="phases" className={`py-16 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t.phases.title}</h2>
            <div className={`w-20 h-1 mx-auto ${theme === 'dark' ? 'bg-blue-500' : 'bg-blue-600'}`}></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* 阶段 1 */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-6 shadow-lg border border-transparent ${theme === 'dark' ? 'bg-gray-800 hover:border-blue-500' : 'bg-white hover:border-blue-400'} transition-all duration-300`}
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${theme === 'dark' ? 'bg-blue-900/50 text-blue-400' : 'bg-blue-100 text-blue-600'}`}>
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t.phases.phase1.title}</h3>
              <p className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>{t.phases.phase1.target}</p>
              <ul className={`space-y-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {t.phases.phase1.actions.map((action, index) => (
                  <li key={index} className="flex items-start">
                    <span className={`mt-1 mr-2 text-sm ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
                      <i className="fas fa-check-circle"></i>
                    </span>
                    {action}
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* 阶段 2 */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-6 shadow-lg border border-transparent ${theme === 'dark' ? 'bg-gray-800 hover:border-purple-500' : 'bg-white hover:border-purple-400'} transition-all duration-300`}
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${theme === 'dark' ? 'bg-purple-900/50 text-purple-400' : 'bg-purple-100 text-purple-600'}`}>
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t.phases.phase2.title}</h3>
              <p className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>{t.phases.phase2.target}</p>
              <ul className={`space-y-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {t.phases.phase2.actions.map((action, index) => (
                  <li key={index} className="flex items-start">
                    <span className={`mt-1 mr-2 text-sm ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                      <i className="fas fa-check-circle"></i>
                    </span>
                    {action}
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* 阶段 3 */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-6 shadow-lg border border-transparent ${theme === 'dark' ? 'bg-gray-800 hover:border-green-500' : 'bg-white hover:border-green-400'} transition-all duration-300`}
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${theme === 'dark' ? 'bg-green-900/50 text-green-400' : 'bg-green-100 text-green-600'}`}>
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t.phases.phase3.title}</h3>
              <p className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-green-400' : 'text-green-600'}`}>{t.phases.phase3.target}</p>
              <ul className={`space-y-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {t.phases.phase3.actions.map((action, index) => (
                  <li key={index} className="flex items-start">
                    <span className={`mt-1 mr-2 text-sm ${theme === 'dark' ? 'text-green-400' : 'text-green-600'}`}>
                      <i className="fas fa-check-circle"></i>
                    </span>
                    {action}
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* 阶段 4 */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-6 shadow-lg border border-transparent ${theme === 'dark' ? 'bg-gray-800 hover:border-amber-500' : 'bg-white hover:border-amber-400'} transition-all duration-300`}
            >
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${theme === 'dark' ? 'bg-amber-900/50 text-amber-400' : 'bg-amber-100 text-amber-600'}`}>
                <span className="text-2xl font-bold">4</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{t.phases.phase4.title}</h3>
              <p className={`text-lg font-semibold mb-4 ${theme === 'dark' ? 'text-amber-400' : 'text-amber-600'}`}>{t.phases.phase4.target}</p>
              <ul className={`space-y-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {t.phases.phase4.actions.map((action, index) => (
                  <li key={index} className="flex items-start">
                    <span className={`mt-1 mr-2 text-sm ${theme === 'dark' ? 'text-amber-400' : 'text-amber-600'}`}>
                      <i className="fas fa-check-circle"></i>
                    </span>
                    {action}
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 十二大增长引擎 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t.engines.title}</h2>
            <div className={`w-20 h-1 mx-auto ${theme === 'dark' ? 'bg-blue-500' : 'bg-blue-600'}`}></div>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={containerVariants}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {[
              t.engines.engine1, t.engines.engine2, t.engines.engine3, t.engines.engine4,
              t.engines.engine5, t.engines.engine6, t.engines.engine7, t.engines.engine8,
              t.engines.engine9, t.engines.engine10, t.engines.engine11, t.engines.engine12
            ].map((engine, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ scale: 1.05 }}
                className={`rounded-xl p-5 shadow-md flex items-start gap-4 ${
                  theme === 'dark' 
                    ? 'bg-gray-900 hover:bg-gray-850' 
                    : 'bg-gray-50 hover:bg-gray-100'
                } transition-all duration-300`}
              >
                <div className={`p-3 rounded-lg ${
                  theme === 'dark' 
                    ? 'bg-blue-900/30 text-blue-400' 
                    : 'bg-blue-100 text-blue-600'
                }`}>
                  {engineIcons[index % engineIcons.length]}
                </div>
                <div>
                  <h3 className="font-semibold mb-2">{`${index + 1}. ${engine}`}</h3>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 三种数学模型 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t.models.title}</h2>
            <div className={`w-20 h-1 mx-auto ${theme === 'dark' ? 'bg-blue-500' : 'bg-blue-600'}`}></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 模型 A */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-8 shadow-lg relative overflow-hidden ${
                theme === 'dark' ? 'bg-gray-800' : 'bg-white'
              }`}
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full opacity-10 bg-blue-500"></div>
              <h3 className="text-2xl font-bold mb-4 relative z-10">{t.models.modelA.title}</h3>
              <div className={`p-4 rounded-xl mb-4 font-mono text-center ${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                {t.models.modelA.formula}
              </div>
              <p className={`text-lg font-semibold ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
                {t.models.modelA.example}
              </p>
            </motion.div>

            {/* 模型 B */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-8 shadow-lg relative overflow-hidden ${
                theme === 'dark' ? 'bg-gray-800' : 'bg-white'
              }`}
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full opacity-10 bg-purple-500"></div>
              <h3 className="text-2xl font-bold mb-4 relative z-10">{t.models.modelB.title}</h3>
              <div className={`p-4 rounded-xl mb-4 font-mono text-center ${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                {t.models.modelB.formula}
              </div>
              <p className={`text-lg font-semibold ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                {t.models.modelB.example}
              </p>
            </motion.div>

            {/* 模型 C */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -10 }}
              className={`rounded-2xl p-8 shadow-lg relative overflow-hidden ${
                theme === 'dark' ? 'bg-gray-800' : 'bg-white'
              }`}
            >
              <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full opacity-10 bg-green-500"></div>
              <h3 className="text-2xl font-bold mb-4 relative z-10">{t.models.modelC.title}</h3>
              <div className={`p-4 rounded-xl mb-4 font-mono text-center ${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                {t.models.modelC.formula}
              </div>
              <p className={`text-lg font-semibold ${theme === 'dark' ? 'text-green-400' : 'text-green-600'}`}>
                {t.models.modelC.example}
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 结论部分 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-800 to-gray-900' : 'bg-gradient-to-b from-white to-blue-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">{t.conclusion.title}</h2>
            <p className={`text-lg mb-10 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.conclusion.description}
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               {[
                { year: "2026", desc: language === 'en' ? "Infrastructure + Global Expansion" : "基础设施 + 全球落地", value: language === 'en' ? "36B - 300B" : "360亿 - 3000亿" },
                { year: "2027", desc: language === 'en' ? "Chinese Economic Entity Unit" : "华人经济体记账单位", value: language === 'en' ? "300B - 1T" : "3000亿 - 1万亿" },
                { year: "2028-2029", desc: language === 'en' ? "Global Stablecoin Position" : "全球稳定币地位", value: language === 'en' ? "1T - 8T" : "1万亿 - 8万亿" },
                { year: "2030", desc: language === 'en' ? "Global CNH Settlement Network" : "全球CNH结算网络", value: language === 'en' ? "8T - 36T" : "8万亿 - 36万亿" }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className={`p-6 rounded-xl ${
                    theme === 'dark' ? 'bg-gray-800' : 'bg-white'
                  } shadow-lg`}
                >
                  <h3 className="text-xl font-bold mb-2">{item.year}</h3>
                  <p className={`text-sm mb-3 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>{item.desc}</p>
                  <p className={`text-xl font-bold ${
                    index === 0 ? 'text-blue-500' : 
                    index === 1 ? 'text-purple-500' : 
                    index === 2 ? 'text-green-500' : 'text-amber-500'
                  }`}>{item.value}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
        </section>

       {/* 三个栏目并排显示区域 */}
       <section className={`py-12 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-white to-blue-50'}`}>
         <div className="container mx-auto px-4">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
             {/* 私募链接 */}
             <div className="text-center">
               <motion.div
                 whileHover={{ scale: 1.05 }}
                 whileTap={{ scale: 0.95 }}
                 className="relative group inline-block"
               >
                 <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-blue-700' : 'bg-blue-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
                 <a 
                   href="/private-placement" 
                   className="relative px-8 py-4 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 transition-all duration-300 text-lg"
                 >
                   {language === 'en' ? 'Explore eCNH Private Placement' : '了解 eCNH 私募'}
                   <ArrowRight className="w-5 h-5" />
                 </a>
               </motion.div>
               <p className={`mt-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                 {language === 'en' ? 'Learn about our 3%-16.8% APR interest calculation methods' : '了解我们3%-16.8%年化收益的计算方式'}
               </p>
             </div>

             {/* 海外8国链接 */}
             <div className="text-center">
               <motion.div
                 whileHover={{ scale: 1.05 }}
                 whileTap={{ scale: 0.95 }}
                 className="relative group inline-block"
               >
                 <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-purple-700' : 'bg-purple-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
                 <a 
                   href="/eight-countries" 
                   className="relative px-8 py-4 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800 transition-all duration-300 text-lg"
                 >
                   {language === 'en' ? 'Explore 8-Country Promotion Center' : '了解海外8国推广中心'}
                   <ArrowRight className="w-5 h-5" />
                 </a>
               </motion.div>
               <p className={`mt-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                 {language === 'en' ? 'Covering 3 billion population in 8 Asian countries' : '覆盖30亿人口的8个亚洲国家'}
               </p>
             </div>

             {/* Logo2026链接 */}
             <div className="text-center">
               <motion.div
                 whileHover={{ scale: 1.05 }}
                 whileTap={{ scale: 0.95 }}
                 className="relative group inline-block"
               >
                 <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-amber-700' : 'bg-amber-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
                 <a 
                   href="/logo2026" 
                   className="relative px-8 py-4 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-yellow-500 text-white hover:from-amber-700 hover:to-yellow-600 transition-all duration-300 text-lg"
                 >
                   {language === 'en' ? 'Explore eCNH Logo 2026' : '探索 eCNH Logo 2026'}
                   <ArrowRight className="w-5 h-5" />
                 </a>
               </motion.div>
               <p className={`mt-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                 {language === 'en' ? 'Discover the visual identity of future finance' : '探索未来金融的视觉标识'}
               </p>
             </div>
           </div>
         </div>
       </section>

       {/* 页脚 */}
      <footer className={`py-12 ${theme === 'dark' ? 'bg-gray-900 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">{t.footer.description}</p>
          <p className="mb-6">{t.footer.coreValue}</p>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>{t.footer.contractAddress}</p>
          <div className="mt-8 flex justify-center space-x-6">
            <a href="https://x.com/earthCNH" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="https://t.me/eCNHusdc" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-telegram text-xl"></i>
            </a>
            <a href="https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fas fa-link text-xl"></i>
            </a>
            <a href="/private-placement" className={`hover:text-blue-500 transition-colors`}>
              <i className="fas fa-chart-line text-xl"></i>
            </a>
            <a href="/logo2026" className={`hover:text-amber-500 transition-colors`}>
              <i className="fas fa-palette text-xl"></i>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}