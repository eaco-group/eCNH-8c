import { useState } from "react";
import { motion } from "framer-motion";
  import { Globe, Star, Compass, Shield, ExternalLink, ChevronRight, Moon, Sun, ArrowRight } from "lucide-react";
  import { useTheme } from "@/hooks/useTheme";

// 语言定义
const languages = {
  zh: {
    title: "eCNH 全球推广中心",
    subtitle: "覆盖30亿人口的8个亚洲国家",
    description: "分布式稳定币 eCNH = EUR + CNH，1 eCNH ≈ 1 CNH ≈ 0.1205 EUR",
    coreValue: "Earth & Global Humanity Builds and Shares eCNH Together",
    exchangeBtn: "兑换 eCNH",
    stargateBtn: "星门连接",
    stats: {
      population: "覆盖人口",
      countries: "目标国家",
      languages: "支持语言",
      commission: "经销返佣"
    },
    guideSectionTitle: "八国 eCNH 兑换指南",
    guideSectionDesc: "覆盖中国周边人口上亿的8个国家，提供本地语言教程和兑换方式",
    viewGuide: "查看兑换指南",
    constellations: "88星座图谱",
    constellationsDesc: "国际天文学联合会(IAU)认证的88个现代星座",
    exploreConstellations: "探索星座",
    stargate: "星门连接",
    stargateDesc: "地球上12个神秘的星门位置，连接高维星系",
    exploreStargate: "探索星门",
    orion: "猎户座探索",
    orionDesc: "eCNH・猎户座跨文明结算体系应用探索",
    exploreOrion: "探索应用",
    security: "安全第一",
    securityDesc: "Web3 钱包安全手册",
    securityPoints: {
      point1: "识别钓鱼风险",
      point1Desc: "了解签名钓鱼、假网站等常见攻击手段",
      point2: "保护资产安全",
      point2Desc: "学习如何正确使用冷钱包和权限管理",
      point3: "eCNH 安全指南",
      point3Desc: "专为 eCNH 用户定制的安全操作手册"
    },
    viewSecurity: "查看完整安全手册",
    stablecoinDesc: "全球共享的分布式SOL链上结算工具，跨境记账单位，结算代币ECNH",
    contractAddress: "Distributed Stablecoin eCNH CA:",
    orionApplication: "eCNH・猎户座应用探索 Orion Application",
    corePositioning: "核心定位",
    corePositioningDesc: "全球共享的分布式SOL链上结算工具，跨境记账单位，以\"人类+硅基文明协同\"为核心，赋能猎户座跨文明经济生态。",
    coreApplications: "三大核心应用",
    coreApp1: "跨文明贸易结算 - 星际基建、戴森球能源",
    coreApp2: "科技协同与惠民落地 - AI楼宇、星际医疗",
    coreApp3: "跨星系治理与公共价值 - 资源众筹、争议仲裁",
    communication: "通信载体：中微子+引力波，激光通信",
    consensus: "共识安全：量子加密+分布式账本",
    smartContract: "智能合约：兼容EVM，双文明适配",
    relatedSites: "相关链接 Related Sites:"
  },
  en: {
    title: "eCNH Global Promotion Center",
    subtitle: "Covering 3 Billion Population in 8 Asian Countries",
    description: "Distributed Stablecoin eCNH = EUR + CNH, 1 eCNH ≈ 1 CNH ≈ 0.1205 EUR",
    coreValue: "Earth & Global Humanity Builds and Shares eCNH Together",
    exchangeBtn: "Exchange eCNH",
    stargateBtn: "Stargate Connection",
    stats: {
      population: "Population",
      countries: "Target Countries",
      languages: "Supported Languages",
      commission: "Distribution Commission"
    },
    guideSectionTitle: "8-Country eCNH Exchange Guide",
    guideSectionDesc: "Covering 8 countries with over 100 million population around China, providing local language tutorials and exchange methods",
    viewGuide: "View Exchange Guide",
    constellations: "88 Constellations",
    constellationsDesc: "88 modern constellations recognized by the International Astronomical Union (IAU)",
    exploreConstellations: "Explore Constellations",
    stargate: "Stargate Connection",
    stargateDesc: "12 mysterious stargate locations on Earth, connecting higher-dimensional galaxies",
    exploreStargate: "Explore Stargate",
    orion: "Orion Exploration",
    orionDesc: "eCNH・Orion Cross-Civilization Settlement System Application Exploration",
    exploreOrion: "Explore Applications",
    security: "Security First",
    securityDesc: "Web3 Wallet Security Manual",
    securityPoints: {
      point1: "Identify Phishing Risks",
      point1Desc: "Understand common attack methods such as signature phishing and fake websites",
      point2: "Protect Asset Security",
      point2Desc: "Learn how to properly use cold wallets and permission management",
      point3: "eCNH Security Guide",
      point3Desc: "Customized security operation manual for eCNH users"
    },
    viewSecurity: "View Complete Security Manual",
    stablecoinDesc: "Global shared distributed SOL chain settlement tool, cross-border accounting unit, settlement token ECNH",
    contractAddress: "Distributed Stablecoin eCNH CA:",
    orionApplication: "eCNH・Orion Application",
    corePositioning: "Core Positioning",
    corePositioningDesc: "Global shared distributed SOL chain settlement tool, cross-border accounting unit, with \"human + silicon-based civilization collaboration\" as the core, empowering the Orion cross-civilization economic ecosystem.",
    coreApplications: "Three Core Applications",
    coreApp1: "Cross-Civilization Trade Settlement - Interstellar Infrastructure, Dyson Sphere Energy",
    coreApp2: "Technology Collaboration and Beneficial Implementation - AI Buildings, Interstellar Medical Care",
    coreApp3: "Cross-Galaxy Governance and Public Value - Resource Crowdfunding, Dispute Arbitration",
    communication: "Communication Carrier: Neutrino + Gravitational Waves, Laser Communication",
    consensus: "Consensus Security: Quantum Encryption + Distributed Ledger",
    smartContract: "Smart Contract: EVM Compatible, Dual Civilization Adaptation",
    relatedSites: "Related Sites:"
  }
};

// 国家数据
const countriesData = [
  {
    code: "INR",
    country: "India",
    countryLocal: "भारत",
    population: "14.6亿",
    flag: "🇮🇳",
    color: "from-orange-500 to-red-600"
  },
  {
    code: "IDR",
    country: "Indonesia",
    countryLocal: "Indonesia",
    population: "2.85亿",
    flag: "🇮🇩",
    color: "from-red-600 to-white"
  },
  {
    code: "PKR",
    country: "Pakistan",
    countryLocal: "پاکستان",
    population: "2.55亿",
    flag: "🇵🇰",
    color: "from-green-600 to-white"
  },
  {
    code: "BDT",
    country: "Bangladesh",
    countryLocal: "বাংলাদেশ",
    population: "1.8亿",
    flag: "🇧🇩",
    color: "from-green-600 to-red-600"
  },
  {
    code: "RUB",
    country: "Russia",
    countryLocal: "Россия",
    population: "1.45亿",
    flag: "🇷🇺",
    color: "from-blue-700 to-red-600"
  },
  {
    code: "JPY",
    country: "Japan",
    countryLocal: "日本",
    population: "1.25亿",
    flag: "🇯🇵",
    color: "from-red-600 to-white"
  },
  {
    code: "PHP",
    country: "Philippines",
    countryLocal: "Pilipinas",
    population: "1.2亿",
    flag: "🇵🇭",
    color: "from-blue-600 to-red-600"
  },
  {
    code: "VND",
    country: "Vietnam",
    countryLocal: "Việt Nam",
    population: "1.0亿",
    flag: "🇻🇳",
    color: "from-red-600 to-yellow-500"
  }
];

// 统计数据
const statsData = [
  { value: "30亿+", label: "population" },
  { value: "8个", label: "countries" },
  { value: "9种", label: "languages" },
  { value: "0.35%", label: "commission" }
];

// 相关链接
const relatedLinks = [
  { name: "Orca DEX", url: "https://www.orca.so/pools?tokens=7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" },
  { name: "Uniswap", url: "https://app.uniswap.org/explore/tokens/solana/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" },
  { name: "Solscan", url: "https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" },
  { name: "9Star", url: "https://9star.base44.app/Home" },
  { name: "eCNH 880M", url: "https://ecnh880m.base44.app/Home" },
  { name: "Europe", url: "https://europe.base44.app/" },
  { name: "Americas", url: "https://americas.base44.app/" },
  { name: "JPY Guide", url: "https://jpy-ecnh.base44.app/" },
  { name: "Telegram", url: "https://t.me/eCNHusdc" }
];

export default function EightCountries() {
  const [language, setLanguage] = useState<'zh' | 'en'>('zh');
  const { theme, toggleTheme } = useTheme();
  const t = languages[language];

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'zh' ? 'en' : 'zh');
  };

  // 动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className={`min-h-screen font-sans ${theme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}>
      {/* 导航栏 */}
      <nav className={`sticky top-0 z-50 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Globe className={`h-8 w-8 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
            <h1 className="text-xl font-bold">eCNH Global</h1>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href="/"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-900 text-white hover:bg-blue-800' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'} transition-colors`}
            >
              {language === 'en' ? 'Home' : '首页'}
            </a>
            <a 
              href="/private-placement"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-700 text-white hover:bg-blue-600' : 'bg-blue-600 text-white hover:bg-blue-700'} transition-colors`}
            >
              {language === 'en' ? 'Private Placement' : '私募'}
            </a>
            <button
              onClick={toggleLanguage}
              className={`px-3 py-1 rounded-full ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors`}
            >
              {language === 'en' ? '中文' : 'English'}
            </button>
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-700'} transition-colors`}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-white'}`}>
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-3xl md:text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
              {t.title}
            </h1>
            <p className="text-xl md:text-2xl font-semibold mb-6 text-blue-600 dark:text-blue-400">
              {t.subtitle}
            </p>
            <p className={`text-lg md:text-xl max-w-3xl mx-auto mb-8 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.description}
            </p>
            <p className={`text-lg font-medium mb-10 ${theme === 'dark' ? 'text-blue-300' : 'text-blue-700'}`}>
              {t.coreValue}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="https://www.orca.so/pools?tokens=7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5"
                target="_blank"
                rel="noopener noreferrer"
                className={`px-8 py-3 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 transition-all duration-300`}
              >
                {t.exchangeBtn}
                <ExternalLink className="w-5 h-5" />
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="#stargate"
                className={`px-8 py-3 rounded-full font-medium flex items-center justify-center gap-2 ${theme === 'dark' ? 'bg-gray-800 text-white hover:bg-gray-700' : 'bg-white text-gray-800 hover:bg-gray-100'} transition-all duration-300`}
              >
                {t.stargateBtn}
                <Compass className="w-5 h-5" />
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 统计数据 */}
      <section className={`py-12 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {statsData.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`p-6 rounded-2xl shadow-lg text-center ${theme === 'dark' ? 'bg-gray-900' : 'bg-blue-50'}`}
              >
                <div className="text-3xl md:text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
                  {stat.value}
                </div>
                <div className={`text-sm md:text-base ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  {t.stats[stat.label as keyof typeof t.stats]}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 八国兑换指南 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold mb-4">{t.guideSectionTitle}</h2>
            <p className={`max-w-3xl mx-auto ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.guideSectionDesc}
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={containerVariants}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {countriesData.map((country, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10, scale: 1.02 }}
                className={`rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} transition-all duration-300`}
              >
                <div className={`h-2 bg-gradient-to-r ${country.color}`}></div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-4xl">{country.flag}</div>
                    <div className={`text-lg font-semibold ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
                      {country.code} → eCNH
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-1">{country.country}</h3>
                  <p className={`text-sm mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>{country.countryLocal}</p>
                  <div className={`text-lg mb-4 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {country.population}
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-full py-2 px-4 rounded-lg flex items-center justify-center gap-2 ${
                      theme === 'dark' 
                        ? 'bg-blue-900/50 text-blue-300 hover:bg-blue-800/50' 
                        : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                    } transition-colors`}
                  >
                    {t.viewGuide}
                    <ChevronRight className="w-4 h-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 探索区域 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 星座图谱 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className={`rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div className={`h-40 overflow-hidden`}>
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Star%20constellations%20map%2C%20night%20sky%2C%20astronomy%2C%20scientific%20illustration&sign=0c63a0bb8d6c7cbb63242e8493c26031" 
                  alt="Constellations Map" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Star className={`${theme === 'dark' ? 'text-yellow-400' : 'text-yellow-500'}`} />
                  {t.constellations}
                </h3>
                <p className={`mb-4 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                  {t.constellationsDesc}
                </p>
                <a 
                  href="#" 
                  className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors`}
                >
                  {t.exploreConstellations}
                  <ChevronRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>

            {/* 星门连接 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              id="stargate"
              className={`rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div className={`h-40 overflow-hidden`}>
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Ancient%20stargate%20structure%2C%20mystical%20energy%20vortex%2C%20cosmic%20gateway&sign=cf7207577ab1818ba57b50eb1217b175" 
                  alt="Stargate Connection" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Compass className={`${theme === 'dark' ? 'text-purple-400' : 'text-purple-500'}`} />
                  {t.stargate}
                </h3>
                <p className={`mb-4 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                  {t.stargateDesc}
                </p>
                <a 
                  href="#" 
                  className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-purple-400 hover:text-purple-300' : 'text-purple-600 hover:text-purple-800'} transition-colors`}
                >
                  {t.exploreStargate}
                  <ChevronRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>

            {/* 猎户座探索 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className={`rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div className={`h-40 overflow-hidden`}>
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Orion%20constellation%20in%20deep%20space%2C%20futuristic%20space%20station%2C%20interstellar%20civilization&sign=40b77056c3b9ca33b46a28eb80e6124e" 
                  alt="Orion Exploration" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Globe className={`${theme === 'dark' ? 'text-blue-400' : 'text-blue-500'}`} />
                  {t.orion}
                </h3>
                <p className={`mb-4 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                  {t.orionDesc}
                </p>
                <a 
                  href="#" 
                  className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors`}
                >
                  {t.exploreOrion}
                  <ChevronRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 安全指南 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="flex flex-col md:flex-row gap-8 items-center"
          >
            <div className={`p-10 rounded-2xl shadow-lg ${theme === 'dark' ? 'bg-blue-900/20' : 'bg-blue-50'} flex-shrink-0`}>
              <Shield className={`w-16 h-16 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl md:text-3xl font-bold mb-6 flex items-center gap-2">
                <Shield className={`${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
                {t.security}
              </h2>
              <p className={`mb-6 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                {t.securityDesc}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                  <h3 className="font-bold mb-2">{t.securityPoints.point1}</h3>
                  <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    {t.securityPoints.point1Desc}
                  </p>
                </div>
                <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                  <h3 className="font-bold mb-2">{t.securityPoints.point2}</h3>
                  <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    {t.securityPoints.point2Desc}
                  </p>
                </div>
                <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                  <h3 className="font-bold mb-2">{t.securityPoints.point3}</h3>
                  <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                    {t.securityPoints.point3Desc}
                  </p>
                </div>
              </div>
              <a 
                href="#" 
                className={`inline-flex items-center gap-2 px-6 py-3 rounded-lg ${
                  theme === 'dark' 
                    ? 'bg-blue-900/50 text-blue-300 hover:bg-blue-800/50' 
                    : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                } transition-colors`}
              >
                {t.viewSecurity}
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 猎户座应用 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold mb-4">{t.orionApplication}</h2>
          </motion.div>

          <div className={`p-8 rounded-2xl shadow-lg mb-12 ${theme === 'dark' ? 'bg-gradient-to-br from-gray-900 to-blue-900/20' : 'bg-gradient-to-br from-white to-blue-50'}`}>
            <h3 className="text-xl font-bold mb-4">{t.corePositioning}</h3>
            <p className={`mb-6 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.corePositioningDesc}
            </p>

            <h3 className="text-xl font-bold mb-4">{t.coreApplications}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'} shadow-md`}>
                <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.coreApp1}
                </p>
              </div>
              <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'} shadow-md`}>
                <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.coreApp2}
                </p>
              </div>
              <div className={`p-4 rounded-xl ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'} shadow-md`}>
                <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.coreApp3}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className={`p-3 rounded-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-blue-50'}`}>
                <p className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.communication}
                </p>
              </div>
              <div className={`p-3 rounded-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-blue-50'}`}>
                <p className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.consensus}
                </p>
              </div>
              <div className={`p-3 rounded-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-blue-50'}`}>
                <p className={`text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  {t.smartContract}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 底部信息 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4 text-center">
          <h3 className={`text-xl font-bold mb-4 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>
            {t.contractAddress}
          </h3>
          <p className="text-lg font-mono mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5
          </p>

          <h3 className="text-xl font-bold mb-4">{t.relatedSites}</h3>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {relatedLinks.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`px-4 py-2 rounded-full text-sm ${
                  theme === 'dark' 
                    ? 'bg-gray-800 text-gray-200 hover:bg-gray-700' 
                    : 'bg-white text-gray-800 hover:bg-gray-100'
                } transition-colors`}
              >
                {link.name}
              </a>
            ))}
          </div>

          <a 
            href="https://www.orca.so/pools?tokens=7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5"
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-2 px-8 py-3 rounded-full font-medium bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 transition-all duration-300`}
          >
            {t.exchangeBtn} on Orca
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
      </section>

       {/* Logo2026链接区域（页脚上方） */}
       <section className={`py-12 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-white to-blue-50'}`}>
         <div className="container mx-auto px-4 text-center">
           <motion.div
             whileHover={{ scale: 1.05 }}
             whileTap={{ scale: 0.95 }}
             className="relative group inline-block"
           >
             <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-amber-700' : 'bg-amber-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
             <a 
               href="/logo2026" 
               className="relative px-10 py-4 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-yellow-500 text-white hover:from-amber-700 hover:to-yellow-600 transition-all duration-300 text-lg"
             >
               {language === 'en' ? 'Explore eCNH Logo 2026' : '探索 eCNH Logo 2026'}
               <ArrowRight className="w-5 h-5" />
             </a>
           </motion.div>
           <p className={`mt-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
             {language === 'en' ? 'Discover the visual identity of future finance' : '探索未来金融的视觉标识'}
           </p>
         </div>
       </section>

       {/* 页脚 */}
      <footer className={`py-12 ${theme === 'dark' ? 'bg-gray-900 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">eCNH：全球共享的分布式SOL链上结算工具，跨境记账单位，结算代币</p>
          <p className="mb-6">核心理念：earth & Global Humanity Builds and Shares eCNH Together</p>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            稳定币地址（CA）：7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5u
          </p>
          <div className="mt-8 flex justify-center space-x-6">
            <a href="https://x.com/earthCNH" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="https://t.me/eCNHusdc" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-telegram text-xl"></i>
            </a>
            <a href="https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fas fa-link text-xl"></i>
            </a>
            <a href="/logo2026" className={`hover:text-amber-500 transition-colors`}>
              <i className="fas fa-palette text-xl"></i>
            </a>
          </div>
          <div className="mt-8">
            <a href="/" className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors`}>
              <i className="fas fa-arrow-left"></i>
              {language === 'en' ? 'Back to Home' : '返回首页'}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}