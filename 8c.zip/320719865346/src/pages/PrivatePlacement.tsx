import { useState } from "react";
import { motion } from "framer-motion";
  import { PieChart, DollarSign, TrendingUp, Repeat, BarChart3, ChevronDown, ChevronUp, ArrowRight } from "lucide-react";
  import { useTheme } from "@/hooks/useTheme";

// 语言定义
const languages = {
  zh: {
    title: "eCNH 私募利息计算说明书",
    scope: "适用范围：",
    scopeDesc: "本说明书适用于 eCNH 私募参与者，用于说明利息计算方式、收益区间及发放规则。eCNH 为基于 Solana 的 CNH 计价链上结算单位，用于跨境贸易、供应链结算与全球华商网络的价值流通。",
    yieldRange: "年化收益范围",
    yieldRangeDesc: "eCNH 私募的年化收益区间为：",
    interestMethods: "利息计算方式",
    method1: {
      title: "1. 固定年化利率（最常见）",
      applicable: "适用于：",
      applicableItems: ["稳定币类项目", "资产抵押类", "现金流稳定的私募"],
      formula: "利息 = 本金 × 年化利率 × 实际天数/365",
      example: "用户投入 10,000 eCNH，年化 12%，持有 90 天：",
      exampleCalc: "利息 = 10000 × 0.12 × 90/365 = 295.89 eCNH",
      ecnhVersion: "用于 eCNH 的版本",
      ecnhVersionDesc: [
        "eCNH 本身是 SOL 链上 CNH 计价的结算工具",
        "利息可按 链上时间戳 精确计算",
        "结算方式：按周期自动发放 eCNH 到用户地址"
      ]
    },
    method2: {
      title: "2. 固定周期收益（按月/按季/按年）",
      applicable: "适用于：",
      applicableItems: ["私募基金", "固定收益类产品", "结构化产品"],
      formula: "利息 = 本金 × 周期利率",
      example: "月利率 1%，投资 10,000 eCNH：",
      exampleCalc: "每月利息 = 10000 × 0.01 = 100 eCNH",
      ecnhVersion: "用于 eCNH 的版本",
      ecnhVersionDesc: [
        "每月/每季度链上发放",
        "可写成 SPL Token 的 定期分红合约"
      ]
    },
    method3: {
      title: "3. 复利（利滚利）",
      applicable: "适用于：",
      applicableItems: ["DeFi", "LP 收益", "自动复投策略"],
      formula: "最终本金 = 本金 × (1 + 利率)ⁿ",
      example: "年化 12%，按月复利（n=12）：",
      exampleCalc: "最终本金 = 10000 × (1 + 0.12/12)¹² = 11268.25",
      ecnhVersion: "用于 eCNH 的版本",
      ecnhVersionDesc: [
        "可结合 Solana 的自动化工具（如 Clockwork）",
        "自动复投到 LP、DLMM、质押池"
      ]
    },
    method4: {
      title: "4. 浮动收益（与项目表现挂钩）",
      applicable: "适用于：",
      applicableItems: ["DAO 分红", "收益共享", "项目利润分成"],
      formula: "利息 = 本金 × 分红比例 × 项目收益率",
      example: "项目季度收益率 8%，分红比例 30%：",
      exampleCalc: "利息 = 10000 × 0.3 × 0.08 = 240 eCNH",
      ecnhVersion: "用于 eCNH 的版本",
      ecnhVersionDesc: [
        "适合 eCNH 的 跨境结算量增长分红",
        "或者 节点收益共享",
        "所有分红均以 eCNH 发放"
      ]
    },
    distributionMethod: "发放方式",
    distributionItems: [
      "利息以 eCNH 发放",
      "发放周期可为：每月 / 每季度 / 到期一次性",
      "所有收益均通过 Solana 链上地址 自动发送"
    ],
    summary: "总结：私募利息的四种主流方式",
    summaryTable: {
      model: "模式",
      features: "特点",
      scenarios: "适用场景",
      suitability: "是否适合 eCNH"
    },
    aprRange: "3% – 16.8% 年化（APR）",
    aprNote: "具体利率由项目阶段、锁定周期、参与额度等因素决定。"
  },
  en: {
    title: "eCNH Private Placement Interest Calculation Guide",
    scope: "Scope:",
    scopeDesc: "This document explains how interest is calculated for participants in the eCNH private placement program. eCNH is a CNH‑denominated settlement token on Solana, designed for cross‑border trade, supply‑chain payments, and global Chinese business networks.",
    yieldRange: "Annual Yield Range",
    yieldRangeDesc: "The annual interest rate for eCNH private placement is:",
    interestMethods: "Interest Calculation Methods",
    method1: {
      title: "1. Fixed Annual Interest Rate (Most Common)",
      applicable: "Applicable to:",
      applicableItems: ["Stablecoin projects", "Asset-backed projects", "Private placements with stable cash flow"],
      formula: "Interest = Principal × APR × Days/365",
      example: "Investment of 10,000 eCNH at 12% APR for 90 days:",
      exampleCalc: "Interest = 10000 × 0.12 × 90/365 = 295.89 eCNH",
      ecnhVersion: "eCNH Version",
      ecnhVersionDesc: [
        "eCNH is a Solana-based CNH-denominated settlement tool",
        "Interest can be calculated precisely using on-chain timestamps",
        "Distribution: eCNH automatically sent to user addresses periodically"
      ]
    },
    method2: {
      title: "2. Fixed Periodic Returns (Monthly/Quarterly/Annual)",
      applicable: "Applicable to:",
      applicableItems: ["Private equity funds", "Fixed income products", "Structured products"],
      formula: "Interest = Principal × Period Rate",
      example: "Monthly rate of 1%, investment of 10,000 eCNH:",
      exampleCalc: "Monthly interest = 10000 × 0.01 = 100 eCNH",
      ecnhVersion: "eCNH Version",
      ecnhVersionDesc: [
        "Monthly/quarterly on-chain distribution",
        "Can be implemented as SPL Token periodic dividend contracts"
      ]
    },
    method3: {
      title: "3. Compound Interest",
      applicable: "Applicable to:",
      applicableItems: ["DeFi", "LP returns", "Auto-reinvestment strategies"],
      formula: "Final Balance = Principal × (1 + Rate)^n",
      example: "12% APR, compounded monthly (n=12):",
      exampleCalc: "Final Balance = 10000 × (1 + 0.12/12)^12 = 11268.25",
      ecnhVersion: "eCNH Version",
      ecnhVersionDesc: [
        "Can integrate with Solana automation tools (e.g., Clockwork)",
        "Auto-reinvestment into LP, DLMM, staking pools"
      ]
    },
    method4: {
      title: "4. Floating Returns (Linked to Project Performance)",
      applicable: "Applicable to:",
      applicableItems: ["DAO dividends", "Revenue sharing", "Project profit distribution"],
      formula: "Interest = Principal × Dividend Ratio × Project Return Rate",
      example: "Project quarterly return rate 8%, dividend ratio 30%:",
      exampleCalc: "Interest = 10000 × 0.3 × 0.08 = 240 eCNH",
      ecnhVersion: "eCNH Version",
      ecnhVersionDesc: [
        "Suitable for eCNH cross-border settlement volume growth dividends",
        "Or node revenue sharing",
        "All dividends distributed in eCNH"
      ]
    },
    distributionMethod: "Distribution Method",
    distributionItems: [
      "Interest is distributed in eCNH",
      "Distribution cycle: monthly / quarterly / at maturity",
      "All payments are sent directly to the user's Solana wallet address"
    ],
    summary: "Summary: Four Main Private Placement Interest Methods",
    summaryTable: {
      model: "Model",
      features: "Features",
      scenarios: "Applicable Scenarios",
      suitability: "Suitability for eCNH"
    },
    aprRange: "3% – 16.8% APR",
    aprNote: "The exact rate depends on project phase, lock-up period, and subscription amount."
  },
  ja: {
    title: "eCNH 私募利息計算ガイド",
    scope: "適用範囲：",
    scopeDesc: "本ガイドは、eCNH 私募参加者向けに利息計算方法と利回り範囲を説明するものです。eCNH は Solana 上の CNH 建て決済トークンであり、越境貿易・サプライチェーン決済に利用されます。",
    yieldRange: "年間利回り範囲",
    yieldRangeDesc: "eCNH 私募の年間利回り（APR）は：",
    interestMethods: "利息計算方法",
    method1: {
      title: "1. 固定年利（最も一般的）",
      applicable: "適用対象：",
      applicableItems: ["ステーブルコインプロジェクト", "資産担保型プロジェクト", "安定したキャッシュフローを持つ私募"],
      formula: "利息 = 元本 × 年利 × 日数/365",
      example: "10,000 eCNH を 12% 年利で 90 日間保有：",
      exampleCalc: "利息 = 10000 × 0.12 × 90/365 = 295.89 eCNH",
      ecnhVersion: "eCNH バージョン",
      ecnhVersionDesc: [
        "eCNH は SOL チェーン上の CNH 建て決済ツールです",
        "利息はチェーン上のタイムスタンプを使用して正確に計算できます",
        "分配方法：定期的にユーザーのアドレスに eCNH を自動送信"
      ]
    },
    method2: {
      title: "2. 固定期間収益（月次/四半期/年次）",
      applicable: "適用対象：",
      applicableItems: ["プライベートエクイティファンド", "固定収益商品", "構造化商品"],
      formula: "利息 = 元本 × 期間利率",
      example: "月利率 1%、10,000 eCNH 投資：",
      exampleCalc: "月間利息 = 10000 × 0.01 = 100 eCNH",
      ecnhVersion: "eCNH バージョン",
      ecnhVersionDesc: [
        "月次/四半期チェーン上分配",
        "SPL トークンの定期配当契約として実装可能"
      ]
    },
    method3: {
      title: "3. 複利（利上げ）",
      applicable: "適用対象：",
      applicableItems: ["DeFi", "LP 収益", "自動再投資戦略"],
      formula: "最終残高 = 元本 × (1 + 利率)ⁿ",
      example: "年利 12%、月次複利（n=12）：",
      exampleCalc: "最終残高 = 10000 × (1 + 0.12/12)¹² = 11268.25",
      ecnhVersion: "eCNH バージョン",
      ecnhVersionDesc: [
        "Solana の自動化ツール（Clockwork など）と統合可能",
        "LP、DLMM、ステーキングプールへの自動再投資"
      ]
    },
    method4: {
      title: "4. 変動収益（プロジェクトのパフォーマンスにリンク）",
      applicable: "適用対象：",
      applicableItems: ["DAO 配当", "収益共有", "プロジェクト利益分配"],
      formula: "利息 = 元本 × 配当率 × プロジェクト収益率",
      example: "プロジェクト四半期収益率 8%、配当率 30%：",
      exampleCalc: "利息 = 10000 × 0.3 × 0.08 = 240 eCNH",
      ecnhVersion: "eCNH バージョン",
      ecnhVersionDesc: [
        "eCNH の国境を越えた決済量の成長配当に適しています",
        "またはノード収益共有",
        "すべての配当は eCNH で配布"
      ]
    },
    distributionMethod: "分配方法",
    distributionItems: [
      "利息は eCNH で支払われます",
      "分配サイクル：月次 / 四半期 / 満期時",
      "すべての支払いはユーザーの Solana ウォレットアドレスに直接送信されます"
    ],
    summary: "まとめ：私募利息の4つの主要方式",
    summaryTable: {
      model: "モデル",
      features: "特徴",
      scenarios: "適用シナリオ",
      suitability: "eCNH への適合性"
    },
    aprRange: "3% ～ 16.8% APR",
    aprNote: "正確な利率はプロジェクトの段階、ロックアップ期間、購入金額によって異なります。"
  },
  vi: {
    title: "Hướng Dẫn Tính Lãi Suất eCNH Private Placement",
    scope: "Phạm vi:",
    scopeDesc: "Tài liệu này giải thích cách tính lãi cho người tham gia chương trình private placement của eCNH. eCNH là token thanh toán định giá CNH trên Solana, dùng cho thương mại xuyên biên giới và chuỗi cung ứng.",
    yieldRange: "Phạm vi lãi suất năm",
    yieldRangeDesc: "Lãi suất năm (APR) của eCNH:",
    interestMethods: "Phương pháp tính lãi",
    method1: {
      title: "1. Lãi suất cố định hàng năm (Thường gặp nhất)",
      applicable: "Áp dụng cho:",
      applicableItems: ["Dự án stablecoin", "Dự án có tài sản thế chấp", "Private placement có dòng tiền ổn định"],
      formula: "Lãi = Vốn × APR × Số ngày/365",
      example: "Đầu tư 10,000 eCNH với APR 12% trong 90 ngày:",
      exampleCalc: "Lãi = 10000 × 0.12 × 90/365 = 295.89 eCNH",
      ecnhVersion: "Phiên bản eCNH",
      ecnhVersionDesc: [
        "eCNH là công cụ thanh toán định giá CNH trên chuỗi Solana",
        "Lãi có thể được tính chính xác bằng dấu thời gian trên chuỗi",
        "Phương thức phân phối: eCNH được gửi tự động đến địa chỉ người dùng định kỳ"
      ]
    },
    method2: {
      title: "2. Lợi nhuận cố định theo kỳ (tháng/quý/năm)",
      applicable: "Áp dụng cho:",
      applicableItems: ["Quỹ private equity", "Sản phẩm thu nhập cố định", "Sản phẩm cấu trúc"],
      formula: "Lãi = Vốn × Lãi suất kỳ hạn",
      example: "Lãi suất hàng tháng 1%, đầu tư 10,000 eCNH:",
      exampleCalc: "Lãi hàng tháng = 10000 × 0.01 = 100 eCNH",
      ecnhVersion: "Phiên bản eCNH",
      ecnhVersionDesc: [
        "Phân phối trên chuỗi hàng tháng/quý",
        "Có thể được triển khai dưới dạng hợp đồng cổ tức định kỳ SPL Token"
      ]
    },
    method3: {
      title: "3. Lãi kép",
      applicable: "Áp dụng cho:",
      applicableItems: ["DeFi", "Lợi nhuận LP", "Chiến lược tự động tái đầu tư"],
      formula: "Số dư cuối = Vốn × (1 + Lãi suất)^n",
      example: "APR 12%, tính lãi kép hàng tháng (n=12):",
      exampleCalc: "Số dư cuối = 10000 × (1 + 0.12/12)^12 = 11268.25",
      ecnhVersion: "Phiên bản eCNH",
      ecnhVersionDesc: [
        "Có thể tích hợp với công cụ tự động hóa Solana (ví dụ: Clockwork)",
        "Tự động tái đầu tư vào LP, DLMM, staking pools"
      ]
    },
    method4: {
      title: "4. Lợi nhuận động (liên kết với hiệu suất dự án)",
      applicable: "Áp dụng cho:",
      applicableItems: ["Cổ tức DAO", "Chia sẻ doanh thu", "Phân配 lợi nhuận dự án"],
      formula: "Lãi = Vốn × Tỷ lệ cổ tức × Tỷ suất sinh lời dự án",
      example: "Tỷ suất sinh lời quý dự án 8%, tỷ lệ cổ tức 30%:",
      exampleCalc: "Lãi = 10000 × 0.3 × 0.08 = 240 eCNH",
      ecnhVersion: "Phiên bản eCNH",
      ecnhVersionDesc: [
        "Thích hợp cho cổ tức tăng trưởng khối lượng thanh toán xuyên biên giới của eCNH",
        "Hoặc chia sẻ doanh thu node",
        "Tất cả cổ tức được phân phối bằng eCNH"
      ]
    },
    distributionMethod: "Phương thức phân phối",
    distributionItems: [
      "Lãi được phân phối bằng eCNH",
      "Chu kỳ phân phối: hàng tháng / hàng quý / khi đáo hạn",
      "Tất cả thanh toán được gửi trực tiếp đến địa chỉ ví Solana của người dùng"
    ],
    summary: "Tóm tắt: Bốn phương pháp chính tính lãi cho private placement",
    summaryTable: {
      model: "Mô hình",
      features: "Tính năng",
      scenarios: "Kịch bản áp dụng",
      suitability: "Tương thích với eCNH"
    },
    aprRange: "3% – 16.8% APR",
    aprNote: "Tỷ lệ cụ thể phụ thuộc vào giai đoạn dự án, thời gian khóa và số tiền tham gia."
  }
};

// 总结表格数据
const summaryData = [
  { 
    model: "固定年化", 
    modelEn: "Fixed Annual", 
    modelJa: "固定年利", 
    modelVi: "Lãi suất cố định hàng năm",
    features: "简单透明", 
    featuresEn: "Simple and Transparent", 
    featuresJa: "シンプルで透明", 
    featuresVi: "Đơn giản và minh bạch",
    scenarios: "稳定币、债权类", 
    scenariosEn: "Stablecoins, Debt Instruments", 
    scenariosJa: "ステーブルコイン、債権類", 
    scenariosVi: "Stablecoin, công cụ nợ",
    suitability: "⭐⭐⭐⭐⭐" 
  },
  { 
    model: "固定周期", 
    modelEn: "Fixed Periodic", 
    modelJa: "固定期間", 
    modelVi: "Lợi nhuận cố định theo kỳ",
    features: "易管理", 
    featuresEn: "Easy to Manage", 
    featuresJa: "管理が容易", 
    featuresVi: "Dễ quản lý",
    scenarios: "私募基金", 
    scenariosEn: "Private Equity Funds", 
    scenariosJa: "プライベートエクイティファンド", 
    scenariosVi: "Quỹ private equity",
    suitability: "⭐⭐⭐⭐" 
  },
  { 
    model: "复利", 
    modelEn: "Compound Interest", 
    modelJa: "複利", 
    modelVi: "Lãi kép",
    features: "收益更高", 
    featuresEn: "Higher Returns", 
    featuresJa: "収益が高い", 
    featuresVi: "Lợi nhuận cao hơn",
    scenarios: "DeFi、LP", 
    scenariosEn: "DeFi, LP", 
    scenariosJa: "DeFi、LP", 
    scenariosVi: "DeFi, LP",
    suitability: "⭐⭐⭐⭐⭐" 
  },
  { 
    model: "浮动收益", 
    modelEn: "Floating Returns", 
    modelJa: "変動収益", 
    modelVi: "Lợi nhuận động",
    features: "与项目绑定", 
    featuresEn: "Linked to Project Performance", 
    featuresJa: "プロジェクトのパフォーマンスにリンク", 
    featuresVi: "Liên kết với hiệu suất dự án",
    scenarios: "DAO、利润分成", 
    scenariosEn: "DAO, Profit Sharing", 
    scenariosJa: "DAO、利益分配", 
    scenariosVi: "DAO, chia sẻ lợi nhuận",
    suitability: "⭐⭐⭐⭐" 
  }
];

// 图标映射
const methodIcons = [
  <DollarSign className="w-6 h-6" />,
  <BarChart3 className="w-6 h-6" />,
  <Repeat className="w-6 h-6" />,
  <TrendingUp className="w-6 h-6" />
];

export default function PrivatePlacement() {
  const [language, setLanguage] = useState<'zh' | 'en' | 'ja' | 'vi'>('zh');
  const { theme, toggleTheme } = useTheme();
  const t = languages[language];
  
  // 可折叠部分的状态
  const [expandedMethod, setExpandedMethod] = useState<number | null>(null);
  
  const toggleMethod = (index: number) => {
    setExpandedMethod(expandedMethod === index ? null : index);
  };
  
  const toggleLanguage = (lang: 'zh' | 'en' | 'ja' | 'vi') => {
    setLanguage(lang);
  };
  
  // 动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className={`min-h-screen font-sans ${theme === 'dark' ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}>
      {/* 导航栏 */}
      <nav className={`sticky top-0 z-50 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-lg transition-all duration-300`}>
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <PieChart className={`h-8 w-8 ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`} />
            <h1 className="text-xl font-bold">eCNH Private Placement</h1>
          </div>
          <div className="flex items-center space-x-4">
            <a 
              href="/"
              className={`px-4 py-2 rounded-full ${theme === 'dark' ? 'bg-blue-900 text-white hover:bg-blue-800' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'} transition-colors`}
            >
              {language === 'zh' ? '首页' : language === 'en' ? 'Home' : language === 'ja' ? 'ホーム' : 'Trang chủ'}
            </a>
            <div className="flex space-x-2">
              <button
                onClick={() => toggleLanguage('zh')}
                className={`px-3 py-1 rounded-full text-sm ${language === 'zh' 
                  ? (theme === 'dark' ? 'bg-blue-700 text-white' : 'bg-blue-600 text-white') 
                  : (theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300')} transition-colors`}
              >
                中文
              </button>
              <button
                onClick={() => toggleLanguage('en')}
                className={`px-3 py-1 rounded-full text-sm ${language === 'en' 
                  ? (theme === 'dark' ? 'bg-blue-700 text-white' : 'bg-blue-600 text-white') 
                  : (theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300')} transition-colors`}
              >
                English
              </button>
              <button
                onClick={() => toggleLanguage('ja')}
                className={`px-3 py-1 rounded-full text-sm ${language === 'ja' 
                  ? (theme === 'dark' ? 'bg-blue-700 text-white' : 'bg-blue-600 text-white') 
                  : (theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300')} transition-colors`}
              >
                日本語
              </button>
              <button
                onClick={() => toggleLanguage('vi')}
                className={`px-3 py-1 rounded-full text-sm ${language === 'vi' 
                  ? (theme === 'dark' ? 'bg-blue-700 text-white' : 'bg-blue-600 text-white') 
                  : (theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300')} transition-colors`}
              >
                Việt
              </button>
            </div>
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-yellow-400' : 'bg-gray-200 text-gray-700'} transition-colors`}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <i className="fas fa-sun"></i>
              ) : (
                <i className="fas fa-moon"></i>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* 英雄区域 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-white'}`}>
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-3xl md:text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
              {t.title}
            </h1>
          </motion.div>
        </div>
      </section>

      {/* 主要内容区域 */}
      <section className={`py-16 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto px-4 max-w-4xl">
          {/* 适用范围 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className={`mb-12 p-6 rounded-2xl shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}
          >
            <h2 className="text-2xl font-bold mb-4">{t.scope}</h2>
            <p className={`${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.scopeDesc}
            </p>
          </motion.div>

          {/* 年化收益范围 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className={`mb-12 p-6 rounded-2xl shadow-lg ${theme === 'dark' ? 'bg-gradient-to-r from-blue-900/30 to-purple-900/30' : 'bg-gradient-to-r from-blue-50 to-purple-50'}`}
          >
            <h2 className="text-2xl font-bold mb-4">{t.yieldRange}</h2>
            <p className="mb-2">{t.yieldRangeDesc}</p>
            <div className={`text-3xl font-bold ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'} mb-4`}>
              {t.aprRange}
            </div>
            <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {t.aprNote}
            </p>
          </motion.div>

          {/* 利息计算方式 */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
            className="mb-12"
          >
            <h2 className="text-2xl font-bold mb-6">{t.interestMethods}</h2>
            
            {/* 方法 1 */}
            <motion.div
              variants={itemVariants}
              className={`mb-6 rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div 
                className={`p-6 cursor-pointer flex justify-between items-center ${theme === 'dark' ? 'hover:bg-gray-850' : 'hover:bg-gray-50'} transition-colors`}
                onClick={() => toggleMethod(0)}
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-blue-900/30 text-blue-400' : 'bg-blue-100 text-blue-600'}`}>
                    {methodIcons[0]}
                  </div>
                  <h3 className="text-xl font-semibold">{t.method1.title}</h3>
                </div>
                {expandedMethod === 0 ? <ChevronUp /> : <ChevronDown />}
              </div>
              
              {expandedMethod === 0 && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`p-6 pt-0 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-100'}`}
                >
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method1.applicable}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method1.applicableItems.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className={`p-4 rounded-lg mb-4 font-mono text-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
                    {t.method1.formula}
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method1.example}</h4>
                    <div className={`p-3 rounded-lg font-mono ${theme === 'dark' ? 'bg-gray-800 text-blue-400' : 'bg-gray-100 text-blue-600'}`}>
                      {t.method1.exampleCalc}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">{t.method1.ecnhVersion}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method1.ecnhVersionDesc.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </motion.div>
            
            {/* 方法 2 */}
            <motion.div
              variants={itemVariants}
              className={`mb-6 rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div 
                className={`p-6 cursor-pointer flex justify-between items-center ${theme === 'dark' ? 'hover:bg-gray-850' : 'hover:bg-gray-50'} transition-colors`}
                onClick={() => toggleMethod(1)}
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-purple-900/30 text-purple-400' : 'bg-purple-100 text-purple-600'}`}>
                    {methodIcons[1]}
                  </div>
                  <h3 className="text-xl font-semibold">{t.method2.title}</h3>
                </div>
                {expandedMethod === 1 ? <ChevronUp /> : <ChevronDown />}
              </div>
              
              {expandedMethod === 1 && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`p-6 pt-0 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-100'}`}
                >
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method2.applicable}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method2.applicableItems.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className={`p-4 rounded-lg mb-4 font-mono text-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
                    {t.method2.formula}
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method2.example}</h4>
                    <div className={`p-3 rounded-lg font-mono ${theme === 'dark' ? 'bg-gray-800 text-purple-400' : 'bg-gray-100 text-purple-600'}`}>
                      {t.method2.exampleCalc}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">{t.method2.ecnhVersion}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method2.ecnhVersionDesc.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </motion.div>
            
            {/* 方法 3 */}
            <motion.div
              variants={itemVariants}
              className={`mb-6 rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div 
                className={`p-6 cursor-pointer flex justify-between items-center ${theme === 'dark' ? 'hover:bg-gray-850' : 'hover:bg-gray-50'} transition-colors`}
                onClick={() => toggleMethod(2)}
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-green-900/30 text-green-400' : 'bg-green-100 text-green-600'}`}>
                    {methodIcons[2]}
                  </div>
                  <h3 className="text-xl font-semibold">{t.method3.title}</h3>
                </div>
                {expandedMethod === 2 ? <ChevronUp /> : <ChevronDown />}
              </div>
              
              {expandedMethod === 2 && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`p-6 pt-0 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-100'}`}
                >
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method3.applicable}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method3.applicableItems.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className={`p-4 rounded-lg mb-4 font-mono text-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
                    {t.method3.formula}
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method3.example}</h4>
                    <div className={`p-3 rounded-lg font-mono ${theme === 'dark' ? 'bg-gray-800 text-green-400' : 'bg-gray-100 text-green-600'}`}>
                      {t.method3.exampleCalc}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">{t.method3.ecnhVersion}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method3.ecnhVersionDesc.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </motion.div>
            
            {/* 方法 4 */}
            <motion.div
              variants={itemVariants}
              className={`mb-6 rounded-2xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
            >
              <div 
                className={`p-6 cursor-pointer flex justify-between items-center ${theme === 'dark' ? 'hover:bg-gray-850' : 'hover:bg-gray-50'} transition-colors`}
                onClick={() => toggleMethod(3)}
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${theme === 'dark' ? 'bg-amber-900/30 text-amber-400' : 'bg-amber-100 text-amber-600'}`}>
                    {methodIcons[3]}
                  </div>
                  <h3 className="text-xl font-semibold">{t.method4.title}</h3>
                </div>
                {expandedMethod === 3 ? <ChevronUp /> : <ChevronDown />}
              </div>
              
              {expandedMethod === 3 && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`p-6 pt-0 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-100'}`}
                >
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method4.applicable}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method4.applicableItems.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className={`p-4 rounded-lg mb-4 font-mono text-center ${theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}`}>
                    {t.method4.formula}
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">{t.method4.example}</h4>
                    <div className={`p-3 rounded-lg font-mono ${theme === 'dark' ? 'bg-gray-800 text-amber-400' : 'bg-gray-100 text-amber-600'}`}>
                      {t.method4.exampleCalc}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">{t.method4.ecnhVersion}</h4>
                    <ul className={`list-disc pl-5 space-y-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                      {t.method4.ecnhVersionDesc.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </motion.div>

          {/* 发放方式 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className={`mb-12 p-6 rounded-2xl shadow-lg ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
          >
            <h2 className="text-2xl font-bold mb-4">{t.distributionMethod}</h2>
            <ul className={`list-disc pl-5 space-y-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              {t.distributionItems.map((item, index) => (
                <li key={index} className="text-lg">{item}</li>
              ))}
            </ul>
          </motion.div>

          {/* 总结表格 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className={`mb-12 p-6 rounded-2xl shadow-lg overflow-x-auto ${theme === 'dark' ? 'bg-gray-900' : 'bg-white'}`}
          >
            <h2 className="text-2xl font-bold mb-6">{t.summary}</h2>
            <table className="w-full min-w-[600px] border-collapse">
              <thead>
                <tr className={theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'}>
                  <th className={`p-4 text-left font-semibold ${theme === 'dark' ? 'border-b border-gray-700' : 'border-b border-gray-200'}`}>{t.summaryTable.model}</th>
                  <th className={`p-4 text-left font-semibold ${theme === 'dark' ? 'border-b border-gray-700' : 'border-b border-gray-200'}`}>{t.summaryTable.features}</th>
                  <th className={`p-4 text-left font-semibold ${theme === 'dark' ? 'border-b border-gray-700' : 'border-b border-gray-200'}`}>{t.summaryTable.scenarios}</th>
                  <th className={`p-4 text-left font-semibold ${theme === 'dark' ? 'border-b border-gray-700' : 'border-b border-gray-200'}`}>{t.summaryTable.suitability}</th>
                </tr>
              </thead>
              <tbody>
                {summaryData.map((item, index) => (
                  <tr 
                    key={index} 
                    className={`${index % 2 === 0 ? 
                      (theme === 'dark' ? 'bg-gray-900' : 'bg-white') : 
                      (theme === 'dark' ? 'bg-gray-850' : 'bg-gray-50')}`}
                  >
                    <td className={`p-4 ${theme === 'dark' ? 'border-b border-gray-800' : 'border-b border-gray-100'}`}>
                      {language === 'zh' ? item.model : 
                       language === 'en' ? item.modelEn : 
                       language === 'ja' ? item.modelJa : item.modelVi}
                    </td>
                    <td className={`p-4 ${theme === 'dark' ? 'border-b border-gray-800' : 'border-b border-gray-100'}`}>
                      {language === 'zh' ? item.features : 
                       language === 'en' ? item.featuresEn : 
                       language === 'ja' ? item.featuresJa : item.featuresVi}
                    </td>
                    <td className={`p-4 ${theme === 'dark' ? 'border-b border-gray-800' : 'border-b border-gray-100'}`}>
                      {language === 'zh' ? item.scenarios : 
                       language === 'en' ? item.scenariosEn : 
                       language === 'ja' ? item.scenariosJa : item.scenariosVi}
                    </td>
                    <td className={`p-4 ${theme === 'dark' ? 'border-b border-gray-800' : 'border-b border-gray-100'}`}>
                      <span className={theme === 'dark' ? 'text-yellow-400' : 'text-yellow-500'}>
                        {item.suitability}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        </div>
      </section>

       {/* Logo2026链接区域（页脚上方） */}
       <section className={`py-12 ${theme === 'dark' ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-white to-blue-50'}`}>
         <div className="container mx-auto px-4 text-center">
           <motion.div
             whileHover={{ scale: 1.05 }}
             whileTap={{ scale: 0.95 }}
             className="relative group inline-block"
           >
             <div className={`absolute inset-0 rounded-full ${theme === 'dark' ? 'bg-amber-700' : 'bg-amber-500'} blur-md group-hover:blur-xl transition-all duration-300`}></div>
             <a 
               href="/logo2026" 
               className="relative px-10 py-4 rounded-full font-medium flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-yellow-500 text-white hover:from-amber-700 hover:to-yellow-600 transition-all duration-300 text-lg"
             >
               {language === 'zh' ? '探索 eCNH Logo 2026' : language === 'en' ? 'Explore eCNH Logo 2026' : language === 'ja' ? 'eCNH ロゴ2026を見る' : 'Khám phá Logo eCNH 2026'}
               <ArrowRight className="w-5 h-5" />
             </a>
           </motion.div>
           <p className={`mt-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
             {language === 'zh' ? '探索未来金融的视觉标识' : language === 'en' ? 'Discover the visual identity of future finance' : language === 'ja' ? '未来の金融の視覚的アイデンティティを発見' : 'Khám phá nhận dạng trực quan của tài chính tương lai'}
           </p>
         </div>
       </section>

       {/* 页脚 */}
      <footer className={`py-12 ${theme === 'dark' ? 'bg-gray-900 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">eCNH：全球共享的分布式SOL链上结算工具，跨境记账单位，结算代币</p>
          <p className="mb-6">核心理念：earth & Global Humanity Builds and Shares eCNH Together</p>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            稳定币地址（CA）：7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5u
          </p>
          <div className="mt-8 flex justify-center space-x-6">
            <a href="https://x.com/earthCNH" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="https://t.me/eCNHusdc" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fab fa-telegram text-xl"></i>
            </a>
            <a href="https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5" target="_blank" rel="noopener noreferrer" className={`hover:text-blue-500 transition-colors`}>
              <i className="fas fa-link text-xl"></i>
            </a>
            <a href="/logo2026" className={`hover:text-amber-500 transition-colors`}>
              <i className="fas fa-palette text-xl"></i>
            </a>
          </div>
          <div className="mt-8">
            <a href="/" className={`inline-flex items-center gap-1 text-sm ${theme === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors`}>
              <i className="fas fa-arrow-left"></i>
              {language === 'zh' ? '返回首页' : language === 'en' ? 'Back to Home' : language === 'ja' ? 'ホームに戻る' : 'Trở về trang chủ'}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}